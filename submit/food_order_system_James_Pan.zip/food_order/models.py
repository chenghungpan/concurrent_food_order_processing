# food_order/models.py

class Order:
    def __init__(self, id, name, temperature, freshness):
        self.id = id
        self.name = name
        self.temperature = temperature
        self.freshness = freshness

# Add similar placeholder classes for Cooler, Heater, and Shelf.

